#!/bin/bash
nohup python main.py >/dev/null 2>&1 &
