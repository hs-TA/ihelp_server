__author__ = 'wei'

class Target :
    def __init__(self):
        self.appId = ""
        self.clientId = ""